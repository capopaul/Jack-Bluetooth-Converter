*PADS-LIBRARY-PART-TYPES-V9*

MCP23008T-E_SO SOIC127P1030X265-18N I ANA 7 1 0 0 0
TIMESTAMP 2025.11.17.16.21.59
"Mouser Part Number" 579-MCP23008T-E/SO
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Microchip-Technology/MCP23008T-E-SO?qs=L9Ynyw3fbhGdT1w2KdF%2FLQ%3D%3D
"Manufacturer_Name" Microchip
"Manufacturer_Part_Number" MCP23008T-E/SO
"Description" Interface - I/O Expanders In/Out I2C int
"Datasheet Link" 
"Geometry.Height" 2.65mm
GATE 1 18 0
MCP23008T-E_SO
1 0 U SCL
2 0 U SDA
3 0 U A2
4 0 U A1
5 0 U A0
6 0 U \RESET
7 0 U NC
8 0 U INT
9 0 U VSS
18 0 U VDD
17 0 U GP7
16 0 U GP6
15 0 U GP5
14 0 U GP4
13 0 U GP3
12 0 U GP2
11 0 U GP1
10 0 U GP0

*END*
*REMARK* SamacSys ECAD Model
625382/1460655/2.50/18/3/Integrated Circuit
